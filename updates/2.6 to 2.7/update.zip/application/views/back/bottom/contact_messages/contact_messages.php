<!--JAVASCRIPT-->
<!--=================================================-->
<!--Pace - Page Load Progress Par [OPTIONAL]-->
<link href="<?=base_url()?>template/back/plugins/pace/pace.min.css" rel="stylesheet">
<script src="<?=base_url()?>template/back/plugins/pace/pace.min.js"></script>
<!--jQuery [ REQUIRED ]-->
<script src="<?=base_url()?>template/back/js/jquery.min.js"></script>
<!--BootstrapJS [ RECOMMENDED ]-->
<script src="<?=base_url()?>template/back/js/bootstrap.min.js"></script>
<!--NiftyJS [ RECOMMENDED ]-->
<script src="<?=base_url()?>template/back/js/nifty.min.js"></script>
<!--=================================================-->
<!--Demo script [ DEMONSTRATION ]-->
<script src="<?=base_url()?>template/back/js/demo/nifty-demo.min.js"></script>
<!--Alerts [ SAMPLE ]-->
<script src="<?=base_url()?>template/back/js/demo/ui-alerts.js"></script>
<!--Text Editor [ SAMPLE ]-->
<script src="<?=base_url()?>template/back/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>