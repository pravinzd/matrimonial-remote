UPDATE `general_settings` SET `value` = '2.7' WHERE `general_settings`.`general_settings_id` = 79;
INSERT INTO `general_settings` (`general_settings_id`, `type`, `value`) VALUES (NULL, 'blur_member_profile_image', 'no');
INSERT INTO `general_settings` (`general_settings_id`, `type`, `value`) VALUES (NULL, 'member_name_show_on_accept_interest', 'no');
